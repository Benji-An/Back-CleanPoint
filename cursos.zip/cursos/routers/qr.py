from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import uvicorn
from datetime import datetime, timedelta
from typing import Optional, List
import jwt
import bcrypt
from pydantic import BaseModel, EmailStr
import sqlite3
import os
from pathlib import Path
import random
import math
from fastapi import APIRouter

# Configuración JWT
SECRET_KEY = "your-secret-key-here"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

security = HTTPBearer()

# Modelos Pydantic
class UserCreate(BaseModel):
    nombre: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    nombre: str
    email: str
    puntos: float
    created_at: datetime

class ContainerInfo(BaseModel):
    codigo: str
    nombre: str
    direccion: str
    sector: str
    coordenadas: dict
    descripcion: Optional[str] = None

class QRScanRequest(BaseModel):
    qr_content: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    accuracy: Optional[float] = None

class QRScanResponse(BaseModel):
    id: int
    points_earned: int
    container_info: ContainerInfo
    distance_to_container: Optional[float] = None
    location_verified: bool
    timestamp: datetime
    total_points: float
    bonus_details: dict

class ScanHistoryResponse(BaseModel):
    id: int
    container_info: ContainerInfo
    points: int
    timestamp: datetime
    user_coordinates: Optional[dict] = None
    distance_to_container: Optional[float] = None
    location_verified: bool

class QRTestResponse(BaseModel):
    qr_content: str
    container_info: ContainerInfo
    is_valid: bool
    message: str

# Inicialización de la base de datos
def init_database():
    """Inicializa la base de datos SQLite"""
    conn = sqlite3.connect('cleancoin.db')
    cursor = conn.cursor()
    
    # Tabla usuarios
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            puntos REAL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Tabla contenedores
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS contenedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT UNIQUE NOT NULL,
            nombre TEXT NOT NULL,
            direccion TEXT NOT NULL,
            sector TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            descripcion TEXT,
            activo BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Tabla escaneos QR
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS qr_scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            contenedor_id INTEGER NOT NULL,
            qr_content TEXT NOT NULL,
            points_earned INTEGER NOT NULL,
            user_latitude REAL,
            user_longitude REAL,
            user_accuracy REAL,
            distance_to_container REAL,
            location_verified BOOLEAN DEFAULT 0,
            bonus_details TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id),
            FOREIGN KEY (contenedor_id) REFERENCES contenedores (id)
        )
    ''')
    
    conn.commit()
    conn.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    init_database()
    yield  # <-- Esto es necesario

# Inicializar FastAPI
app = FastAPI(lifespan=lifespan)

# Crear directorio para archivos estáticos si no existe (antes de montar)
Path("static").mkdir(exist_ok=True)

# Servir archivos estáticos
app.mount("/static", StaticFiles(directory="static"), name="static")

# Funciones auxiliares
def get_db_connection():
    """Obtiene conexión a la base de datos"""
    conn = sqlite3.connect('cleancoin.db')
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password: str) -> str:
    """Hashea una contraseña"""
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    """Verifica una contraseña"""
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Crea un token JWT"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Obtiene el usuario actual del token JWT"""
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: int = payload.get("sub")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario no encontrado",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return dict(user)

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calcula la distancia entre dos puntos geográficos en metros"""
    R = 6371000  # Radio de la Tierra en metros
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    a = (math.sin(delta_lat / 2) * math.sin(delta_lat / 2) +
         math.cos(lat1_rad) * math.cos(lat2_rad) *
         math.sin(delta_lon / 2) * math.sin(delta_lon / 2))
    
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distance = R * c
    
    return distance

def calculate_points_and_bonus(container_code: str, user_lat: Optional[float], user_lon: Optional[float], 
                              container_lat: float, container_lon: float) -> tuple:
    """Calcula puntos y bonus basado en la ubicación y tipo de contenedor"""
    base_points = 50
    bonus_details = {
        "base_points": base_points,
        "location_bonus": 0,
        "proximity_bonus": 0,
        "sector_bonus": 0,
        "accuracy_bonus": 0
    }
    
    total_bonus = 0
    location_verified = False
    distance = None
    
    # Bonus por tener ubicación GPS
    if user_lat and user_lon:
        bonus_details["location_bonus"] = 10
        total_bonus += 10
        
        # Calcular distancia al contenedor
        distance = calculate_distance(user_lat, user_lon, container_lat, container_lon)
        
        # Bonus por proximidad al contenedor
        if distance <= 50:  # Dentro de 50 metros
            bonus_details["proximity_bonus"] = 30
            total_bonus += 30
            location_verified = True
        elif distance <= 100:  # Dentro de 100 metros
            bonus_details["proximity_bonus"] = 20
            total_bonus += 20
            location_verified = True
        elif distance <= 200:  # Dentro de 200 metros
            bonus_details["proximity_bonus"] = 10
            total_bonus += 10
    
    # Bonus por sector (Comuna 2 es zona prioritaria)
    if "COMUNA_2" in container_code.upper():
        bonus_details["sector_bonus"] = 25
        total_bonus += 25
    elif "BAHIA" in container_code.upper():
        bonus_details["sector_bonus"] = 20
        total_bonus += 20
    
    # Bonus por precisión de ubicación
    if location_verified:
        bonus_details["accuracy_bonus"] = 15
        total_bonus += 15
    
    total_points = base_points + total_bonus
    
    return total_points, bonus_details, location_verified, distance

def get_container_by_code(container_code: str):
    """Obtiene información del contenedor por código"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM contenedores WHERE codigo = ? AND activo = 1", (container_code,))
    container = cursor.fetchone()
    conn.close()
    
    return dict(container) if container else None

router = APIRouter(prefix="/QR", tags=["QR"])

# ENDPOINTS DE AUTENTICACIÓN

@router.post("/api/auth/register", response_model=dict)
async def register(user: UserCreate):
    """Registra un nuevo usuario"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Verificar si el email ya existe
    cursor.execute("SELECT id FROM usuarios WHERE email = ?", (user.email,))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El email ya está registrado"
        )
    
    # Crear usuario
    password_hash = hash_password(user.password)
    cursor.execute(
        "INSERT INTO usuarios (nombre, email, password_hash) VALUES (?, ?, ?)",
        (user.nombre, user.email, password_hash)
    )
    user_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    # Crear token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user_id}, expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "message": "Usuario registrado exitosamente"
    }

@router.post("/api/auth/login", response_model=dict)
async def login(user: UserLogin):
    """Inicia sesión de usuario"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM usuarios WHERE email = ?", (user.email,))
    db_user = cursor.fetchone()
    conn.close()
    
    if not db_user or not verify_password(user.password, db_user['password_hash']):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": db_user['id']}, expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": db_user['id'],
            "nombre": db_user['nombre'],
            "email": db_user['email'],
            "puntos": db_user['puntos']
        }
    }

# ENDPOINTS DE USUARIO

@router.get("/api/user/profile", response_model=UserResponse)
async def get_profile(current_user: dict = Depends(get_current_user)):
    """Obtiene el perfil del usuario actual"""
    return UserResponse(
        id=current_user['id'],
        nombre=current_user['nombre'],
        email=current_user['email'],
        puntos=current_user['puntos'],
        created_at=datetime.fromisoformat(current_user['created_at'])
    )

@router.get("/api/user/points", response_model=dict)
async def get_user_points(current_user: dict = Depends(get_current_user)):
    """Obtiene los puntos del usuario"""
    return {
        "points": current_user['puntos'],
        "user_id": current_user['id']
    }

# ENDPOINTS DE CONTENEDORES

@router.get("/api/containers", response_model=List[ContainerInfo])
async def get_containers():
    """Obtiene lista de todos los contenedores activos"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM contenedores WHERE activo = 1 ORDER BY sector, nombre")
    containers = cursor.fetchall()
    conn.close()
    
    result = []
    for container in containers:
        result.append(ContainerInfo(
            codigo=container['codigo'],
            nombre=container['nombre'],
            direccion=container['direccion'],
            sector=container['sector'],
            coordenadas={
                "latitude": container['latitude'],
                "longitude": container['longitude']
            },
            descripcion=container['descripcion']
        ))
    
    return result

@router.get("/api/containers/{container_code}", response_model=ContainerInfo)
async def get_container_info(container_code: str):
    """Obtiene información detallada de un contenedor específico"""
    container = get_container_by_code(container_code)
    
    if not container:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contenedor no encontrado"
        )
    
    return ContainerInfo(
        codigo=container['codigo'],
        nombre=container['nombre'],
        direccion=container['direccion'],
        sector=container['sector'],
        coordenadas={
            "latitude": container['latitude'],
            "longitude": container['longitude']
        },
        descripcion=container['descripcion']
    )

# ENDPOINTS DE ESCÁNER QR

@router.post("/api/qr/test", response_model=QRTestResponse)
async def test_qr_code(qr_content: str):
    """Prueba si un código QR es válido sin registrar el escaneo"""
    container = get_container_by_code(qr_content)
    
    if not container:
        return QRTestResponse(
            qr_content=qr_content,
            container_info=ContainerInfo(
                codigo="",
                nombre="",
                direccion="",
                sector="",
                coordenadas={}
            ),
            is_valid=False,
            message="Código QR no válido o contenedor no encontrado"
        )
    
    container_info = ContainerInfo(
        codigo=container['codigo'],
        nombre=container['nombre'],
        direccion=container['direccion'],
        sector=container['sector'],
        coordenadas={
            "latitude": container['latitude'],
            "longitude": container['longitude']
        },
        descripcion=container['descripcion']
    )
    
    return QRTestResponse(
        qr_content=qr_content,
        container_info=container_info,
        is_valid=True,
        message=f"Contenedor válido: {container['nombre']}"
    )

@router.post("/api/qr/scan", response_model=QRScanResponse)
async def process_qr_scan(scan_data: QRScanRequest, current_user: dict = Depends(get_current_user)):
    """Procesa un escaneo de código QR"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Verificar si el contenedor existe
    container = get_container_by_code(scan_data.qr_content)
    if not container:
        conn.close()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contenedor no encontrado o código QR inválido"
        )
    
    # Verificar si ya se escaneó este contenedor recientemente (últimas 24 horas)
    cursor.execute("""
        SELECT id FROM qr_scans 
        WHERE usuario_id = ? AND contenedor_id = ? 
        AND timestamp > datetime('now', '-24 hours')
    """, (current_user['id'], container['id']))
    
    if cursor.fetchone():
        conn.close()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ya escaneaste este contenedor en las últimas 24 horas"
        )
    
    # Calcular puntos y bonus
    points_earned, bonus_details, location_verified, distance = calculate_points_and_bonus(
        container['codigo'],
        scan_data.latitude,
        scan_data.longitude,
        container['latitude'],
        container['longitude']
    )
    
    # Registrar escaneo
    cursor.execute("""
        INSERT INTO qr_scans 
        (usuario_id, contenedor_id, qr_content, points_earned, user_latitude, user_longitude, 
         user_accuracy, distance_to_container, location_verified, bonus_details)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        current_user['id'], container['id'], scan_data.qr_content, points_earned,
        scan_data.latitude, scan_data.longitude, scan_data.accuracy,
        distance, location_verified, str(bonus_details)
    ))
    
    scan_id = cursor.lastrowid
    
    # Actualizar puntos del usuario
    new_total = current_user['puntos'] + points_earned
    cursor.execute(
        "UPDATE usuarios SET puntos = ? WHERE id = ?",
        (new_total, current_user['id'])
    )
    
    conn.commit()
    
    # Obtener timestamp del escaneo
    cursor.execute("SELECT timestamp FROM qr_scans WHERE id = ?", (scan_id,))
    timestamp = cursor.fetchone()['timestamp']
    
    conn.close()
    
    container_info = ContainerInfo(
        codigo=container['codigo'],
        nombre=container['nombre'],
        direccion=container['direccion'],
        sector=container['sector'],
        coordenadas={
            "latitude": container['latitude'],
            "longitude": container['longitude']
        },
        descripcion=container['descripcion']
    )
    
    return QRScanResponse(
        id=scan_id,
        points_earned=points_earned,
        container_info=container_info,
        distance_to_container=distance,
        location_verified=location_verified,
        timestamp=datetime.fromisoformat(timestamp),
        total_points=new_total,
        bonus_details=bonus_details
    )

@router.get("/api/qr/history", response_model=List[ScanHistoryResponse])
async def get_scan_history(current_user: dict = Depends(get_current_user)):
    """Obtiene el historial de escaneos del usuario"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT s.*, c.codigo, c.nombre, c.direccion, c.sector, c.latitude, c.longitude, c.descripcion
        FROM qr_scans s
        JOIN contenedores c ON s.contenedor_id = c.id
        WHERE s.usuario_id = ? 
        ORDER BY s.timestamp DESC 
        LIMIT 50
    """, (current_user['id'],))
    
    scans = cursor.fetchall()
    conn.close()
    
    result = []
    for scan in scans:
        user_coordinates = None
        if scan['user_latitude'] and scan['user_longitude']:
            user_coordinates = {
                "latitude": scan['user_latitude'],
                "longitude": scan['user_longitude'],
                "accuracy": scan['user_accuracy']
            }
        
        container_info = ContainerInfo(
            codigo=scan['codigo'],
            nombre=scan['nombre'],
            direccion=scan['direccion'],
            sector=scan['sector'],
            coordenadas={
                "latitude": scan['latitude'],
                "longitude": scan['longitude']
            },
            descripcion=scan['descripcion']
        )
        
        result.append(ScanHistoryResponse(
            id=scan['id'],
            container_info=container_info,
            points=scan['points_earned'],
            timestamp=datetime.fromisoformat(scan['timestamp']),
            user_coordinates=user_coordinates,
            distance_to_container=scan['distance_to_container'],
            location_verified=bool(scan['location_verified'])
        ))
    
    return result

# ENDPOINTS GENERALES

@router.get("/api/health")
async def health_check():
    """Endpoint de salud de la API"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow(),
        "version": "1.0.0",
        "service": "CleanCoin QR Scanner API"
    }

@router.get("/api/stats")
async def get_stats():
    """Obtiene estadísticas generales de la aplicación"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Total usuarios
    cursor.execute("SELECT COUNT(*) as total FROM usuarios")
    total_users = cursor.fetchone()['total']
    
    # Total escaneos
    cursor.execute("SELECT COUNT(*) as total FROM qr_scans")
    total_scans = cursor.fetchone()['total']
    
    # Total contenedores activos
    cursor.execute("SELECT COUNT(*) as total FROM contenedores WHERE activo = 1")
    total_containers = cursor.fetchone()['total']
    
    # Total puntos distribuidos
    cursor.execute("SELECT SUM(puntos) as total FROM usuarios")
    total_points = cursor.fetchone()['total'] or 0
    
    # Escaneos por sector
    cursor.execute("""
        SELECT c.sector, COUNT(*) as total_scans
        FROM qr_scans s
        JOIN contenedores c ON s.contenedor_id = c.id
        GROUP BY c.sector
        ORDER BY total_scans DESC
    """)
    scans_by_sector = [{"sector": row['sector'], "scans": row['total_scans']} 
                      for row in cursor.fetchall()]
    
    # Escaneos verificados por ubicación
    cursor.execute("SELECT COUNT(*) as total FROM qr_scans WHERE location_verified = 1")
    verified_scans = cursor.fetchone()['total']
    
    conn.close()
    
    return {
        "total_users": total_users,
        "total_scans": total_scans,
        "total_containers": total_containers,
        "total_points": total_points,
        "verified_scans": verified_scans,
        "scans_by_sector": scans_by_sector
    }
